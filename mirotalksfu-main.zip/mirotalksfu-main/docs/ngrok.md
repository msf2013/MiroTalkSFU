# MiroTalk SFU - Ngrok

### What is the purpose and functionality of Ngrok?

[https://docs.mirotalk.com/ngrok/ngrok/](https://docs.mirotalk.com/ngrok/ngrok/)

### How to exposing MiroTalk SFU with Ngrok?

[https://docs.mirotalk.com/mirotalk-sfu/ngrok/](https://docs.mirotalk.com/mirotalk-sfu/ngrok/)

---
