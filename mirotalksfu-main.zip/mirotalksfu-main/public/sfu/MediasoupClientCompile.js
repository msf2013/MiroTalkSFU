const client = require('mediasoup-client');
window.mediasoupClient = client;
