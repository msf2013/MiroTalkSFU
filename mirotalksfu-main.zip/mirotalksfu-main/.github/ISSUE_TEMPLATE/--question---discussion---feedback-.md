---
name: "\U0001F64BQuestion - discussion - feedback."
about: Anything not related to bugs or features request.
title: ''
labels: ''
assignees: ''

---

## Discord chat

Join with us on Discord and ask questions, create discussion, leave feedback.

- https://discord.gg/rgGYfeYW3N
